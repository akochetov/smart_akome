# Pi Switch

Pi Switch is a library for controlling 315/433MHz remote power outlet sockets.

Pi Switch is a port of the [rc-switch](http://code.google.com/p/rc-switch/) library
for the Raspberry Pi.
