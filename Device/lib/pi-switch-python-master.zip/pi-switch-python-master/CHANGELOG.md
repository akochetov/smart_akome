## Changelog

##### 0.4.0
  * Implement RCSwitchReceiver class
    * pi_switch can now be used to send data from one Raspberry Pi to another!

##### 0.3.1
  * Refactor RCSwitch.cpp
    * Fixes some compiler warnings. But still need to pass '-Wno-write-strings'
      to the compiler to fix the warning `deprecated conversion from string constant to ‘char*’`

##### before 0.3.1
  * There was no Changelog. :-)
