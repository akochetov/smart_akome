BlockingConnection
------------------
.. automodule:: pika.adapters.blocking_connection

Be sure to check out examples in :doc:`/examples`.

.. autoclass:: pika.adapters.blocking_connection.BlockingConnection
  :members:
  :inherited-members:

.. autoclass:: pika.adapters.blocking_connection.BlockingChannel
  :members:
  :inherited-members:
